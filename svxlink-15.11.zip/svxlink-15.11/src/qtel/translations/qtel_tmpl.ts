<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ComDialog</name>
    <message>
        <source>Qtel Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Station data not found in directory server.
Can&apos;t create connection to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not create connection to remote host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>INFO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connected to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connecting to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disconnected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open mic audio device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open speaker audio device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not create connection to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ComDialogBase</name>
    <message>
        <source>Communication Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Station Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP-address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chat/Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOX Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dB Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PTT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EchoLinkDirectoryModel</name>
    <message>
        <source>Callsign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location/Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Logging off from directory server...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Station list has been refreshed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refreshing station list...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtel - Add station...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter callsign of the station to add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtel: Connect to IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter an IP address or hostname:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Repeaters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qtel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtel v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Qt EchoLink client.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright (C) 2011 Tobias Blomberg / SM0SVX

Qtel comes with ABSOLUTELY NO WARRANTY. This is free software, and you are welcome to redistribute it in accordance with the terms and conditions in the GNU GPL (General Public License) version 2 or later.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <source>Qtel - the Qt EchoLink Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Repeaters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Callsign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qtel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit the Qtel application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtel Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open the Qtel settings dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh station list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View as busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View as busy in directory server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to IP...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to selected...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incoming Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Station</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;ettings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to &amp;selected...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to &amp;IP...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtel &amp;Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Selected To &amp;Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add the selected station in the station list to the bookmarks menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove Selected From Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected station from the bookmarks list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add &amp;Named Station To Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to the selected station</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to local station using IP address or hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Immediately refresh the station list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add selected station to the bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the selected station from the bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a station to the bookmarks by entering a callsign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show the about dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tamil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unicode, 8-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Western</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Central European</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hebrew, visually ordered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hebrew, logically ordered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtel: Password mismatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passwords do not match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtel: Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Callsign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retype password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Info
Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directory Server Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time, in minutes, between station list refreshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start as busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register as busy on program startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sound Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mic audio device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The audio device to use (e.g. alsa:default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speaker audio device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full duplex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check this check box to enable full duplex operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The connect sound to use on incoming EchoLink connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QSO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QSO Dialog Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chat encoding:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a connect sound file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Raw Sound Files (*.raw)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Servers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A space separated list of the hostname or IP address of the EchoLink directory servers to use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EchoLink Proxy Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If enabling EchoLink proxy you must supply a proxy server hostname or IP address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The hostname or IP address of the EchoLink proxy server to use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The TCP port to connect to on the EchoLink proxy server, default 8100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The EchoLink PROXY password, not your normal EchoLink password. Leave empty for public proxy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sampling Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EchoLink proxy configuration problem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EchoLink proxy enabled but no server given</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bind address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;A bind address can be specified to force Qtel to use a specific network interface if your computer has more than one. Specify the IP address of the interface to bind to.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
